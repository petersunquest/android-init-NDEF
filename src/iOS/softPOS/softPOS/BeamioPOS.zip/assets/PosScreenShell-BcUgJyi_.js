import{aA as s,$ as n}from"./index-BikYSc9O.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=r=>r.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),x=r=>r.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,t,o)=>o?o.toUpperCase():t.toLowerCase()),l=r=>{const e=x(r);return e.charAt(0).toUpperCase()+e.slice(1)},m=(...r)=>r.filter((e,t,o)=>!!e&&e.trim()!==""&&o.indexOf(e)===t).join(" ").trim(),w=r=>{for(const e in r)if(e.startsWith("aria-")||e==="role"||e==="title")return!0};/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var b={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=s.forwardRef(({color:r="currentColor",size:e=24,strokeWidth:t=2,absoluteStrokeWidth:o,className:i="",children:a,iconNode:u,...c},f)=>s.createElement("svg",{ref:f,...b,width:e,height:e,stroke:r,strokeWidth:o?Number(t)*24/Number(e):t,className:m("lucide",i),...!a&&!w(c)&&{"aria-hidden":"true"},...c},[...u.map(([d,h])=>s.createElement(d,h)),...Array.isArray(a)?a:[a]]));/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=(r,e)=>{const t=s.forwardRef(({className:o,...i},a)=>s.createElement(v,{ref:a,iconNode:e,className:m(`lucide-${p(l(r))}`,`lucide-${r}`,o),...i}));return t.displayName=l(r),t};function $({children:r,className:e="",bg:t="bg-white"}){return n.jsx("div",{className:`flex h-dvh max-h-dvh w-full max-w-[100vw] flex-col overflow-hidden overscroll-none text-mkt-onSurface ${t} ${e}`.trim(),children:r})}function k({children:r,className:e=""}){return n.jsx("header",{className:`shrink-0 pt-[max(0.75rem,env(safe-area-inset-top))] ${e}`.trim(),children:r})}function A({children:r,className:e=""}){return n.jsx("main",{className:`flex min-h-0 flex-1 flex-col overflow-hidden ${e}`.trim(),children:r})}function j({children:r,className:e=""}){return n.jsx("footer",{className:`shrink-0 border-t border-slate-200/80 bg-white/95 px-6 py-4 pb-[max(1rem,env(safe-area-inset-bottom))] backdrop-blur ${e}`.trim(),children:r})}export{j as P,k as a,A as b,$ as c,g as d};
