import{d as c}from"./PosScreenShell-BcUgJyi_.js";import{aJ as s,ah as u}from"./index-BikYSc9O.js";/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const l=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],x=c("circle-check",l);/**
 * @license lucide-react v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]],y=c("credit-card",m);function g(n=new Date){const t=n.toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}),e=n.toLocaleTimeString("en-US",{hour:"numeric",minute:"2-digit"});return`${t}, ${e}`}function $(n){const t=n.trim();return t.length>12?`${t.slice(0,7)}…${t.slice(-5)}`:t}function d(n){const t=n==null?void 0:n.trim();return t?t.length>10?s(t):t:null}function a(n){const t=n.trim();if(!t)return null;let e=t;return!e.startsWith("0x")&&!e.startsWith("0X")&&e.length===64&&/^[0-9a-fA-F]+$/.test(e)&&(e=`0x${e.toLowerCase()}`),e}function C(n){const t=a(n);return t?`https://basescan.org/tx/${t}`:null}function T(n){const t=a(n);return t?`https://mainnet.conet.network/tx/${t}`:null}function b(n,t){const e=u(t);return Math.max(0,n*(e/100))}function h(n){const t=(n==null?void 0:n.trim())??"";return t&&t.replace(/\s+CARD$/i,"").replace(/\s+Card$/i,"").trim()||"—"}function k(n){var i,o;let t=((i=n.customerBeamioTag)==null?void 0:i.trim())??"";if(t.startsWith("@")&&(t=t.slice(1)),t)return t;const e=(o=n.customerWalletAddress)==null?void 0:o.trim();if(e!=null&&e.startsWith("0x")&&e.length>=10)return s(e);const r=h(n.cardName);return r!=="—"?r:"Member"}export{x as C,y as a,C as b,b as c,T as d,h as e,g as f,d as g,k as p,$ as s};
