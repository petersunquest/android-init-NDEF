const o="0.1.80",s={version:o},n=s.version;export{n as A};
