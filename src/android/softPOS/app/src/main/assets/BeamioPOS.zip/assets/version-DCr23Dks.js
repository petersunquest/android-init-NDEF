const o="0.1.87",s={version:o},n=s.version;export{n as A};
